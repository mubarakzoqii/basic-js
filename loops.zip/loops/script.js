for (let count = 0; count <= 10; count++) {
console.log(count);
    
}

let num = 10;

do {
    num++
    console.log(num);
} while (num <= 20 );

