
let todayWeather = "rainy"


if (todayWeather) {
    // statement 
    console.log(todayWeather);
    
}


let todayWeather1 = "rainy";



if (todayWeather1 == "rainy") {
    console.log(todayWeather1, "its rainy");
    // statement
} else {
    console.log("its sunny day");
}

// 


let temperature  = 10;

if (temperature > 25) {
  
    console.log("its a hot day!"); // false
} else if(temperature > 20) { //  false 
   console.log("its a pleasant day!");
}

else {
console.log("cold !");
}

let  fruit = "kiwi"
switch (fruit) {
    case "kiwi":
            console.log("kiwi"); //true
        break;
    case "mango":
        console.log("mango ");
        break;
    case "apple":
        console.log("apple");
        break;
    default:
        console.log("none of these!!!");
        break;
}

