// Q no.1  Use Boolean 
let weatherCond ="isRainy";
let suggest;
    
if(weatherCond === "isSunnay"){
    suggest ="Enjoy the sunshine"
}else if(weatherCond === "isCouldy"){
    suggest ="Bring an umbrella"
}else if(weatherCond === "isRainy"){
    suggest ="Bring an umbrella"
}

console.log(suggest);



// Q no.2  Use else Condition
let age = 17;

if (age >= 18) {
    console.log("You are eligible to vote");
} else{
    console.log("You are not eligible to vote");
}



// Q no.3 Use else if condition

let  weather= "cold";
let recommend;

if(weather === "sunnay"){
    recommend ="wear light clothes"
}else if(weather === "rainy"){
    recommend ="Bring an umbrella"
}else if(weather === "cold"){
    recommend ="wear a jacket"
}

console.log("I recommend to", recommend);


// Q no.4 Use switch statement

let day = 6;
switch (day) {
    case 1:
    console.log("Monday");
    break;
    case 2:
    console.log("Tuesday");
    break;
    case 3:
    console.log("Wednesday");
    break;
    case 4:
    console.log("Thursday");
    break;
    case 5:
    console.log("Friday");
    break;
    case 6:
    console.log("Saturady");
    break;
    case 7:
    console.log("Sunday");
    break;

    default:
        console.log("Invalid input");
        break;
}


// Q no.5 Use Function

function checkEvenOdd(number){
    if (number%2 ===0) {
        return "Even"
    }else {
        return "Odd"
    }
    if(!Number.isInteger(number)){
        return "invalid"
    }


}

console.log(checkEvenOdd(6));



// q NO.6 Use Higher order & CallBack Function


function greetUser(name, callBack) {
    callBack(name)
}
function sayHello(name) {
    console.log("Hello","" + name);
}
greetUser("Muntazir", sayHello)



// Q no.7 Array

let favoriteFurits  = ["apple", "pine apple", "watermelon"];
let additionalFurits = ["banana", "orange", "mango"];

furits = favoriteFurits.concat(additionalFurits);
console.log(furits);

// length
console.log(furits.length);

// push()
furits.push("peach", "kiwi")
console.log(furits);

// pop()
furits.pop()
console.log(furits);

//  shift()
furits.shift()
console.log(furits);

// unshift
furits.unshift("graps")
console.log(furits);




let evenNumber =[2, 4, 6, 8, 6,10, 12, 14]

//IndexOf
console.log(evenNumber.indexOf(8));  
console.log(evenNumber);

// unShift
evenNumber.unshift(16, 18)
console.log(evenNumber);

//  slice() [start , end ]
console.log(evenNumber.slice(2,7));

// splice() [start, delete , end]
console.log(evenNumber.splice(2, 0, "a", "b"));
console.log(evenNumber);

// find()
let sameNum =evenNumber.find((index) =>{
    return index === 6
})

console.log(sameNum , "Find Number");

// Filter

sameNum = evenNumber.filter((index)=>{
    return index === 6
})
console.log(sameNum, "FILTER NUMBER");
