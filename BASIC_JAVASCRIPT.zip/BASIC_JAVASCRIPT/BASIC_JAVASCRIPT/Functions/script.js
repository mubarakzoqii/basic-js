// function stdGrades(marks){
//     if (marks >= 33 && marks <=49) {
//         return "Pass"
//     }else if(marks > 40 && marks <= 49 ) {
//         return "D"
//     }
//     else if(marks > 50 && marks <= 59 ) {
//         return "C"
//     }else if(marks > 60 && marks <= 69 ) {
//         return "B"
//     }else if(marks > 70 && marks <= 89 ) {
//         return "A"
//     } 
//     else if(marks > 90 && marks <= 100 ) {
//         return "A+"
//     } else{
//         console.log("sorry you're fail!");
//     }

// }

// console.log(stdGrades(95));






// functioScope

//   function functionScope() {

//     // var a = 2;
//     // var b = 4;
//     // console.log("a = " , a ,"b =",b);
    
//     if (true) {
//         var a = 2
//         console.log("The value of a =" , a);
//     }
//     if (true) {
//         var b = 4
//         console.log("The value of b =" , b);
//     }
//     console.log(a + b );
    
// }
// functionScope()


// // BlockScope

// function BlockScope() {
//     let a = 5;
//     let b = 10;

//     let result = a * b;

//     return result;
// }


// let multiplication = BlockScope();


// console.log("The result of multiplying  is:", multiplication);




// Callbacks and Higher Order Functions
    
    function subOfTwo(callback1){
    let subtract = "Muntazir";
    callback1(subtract) 
    }
    
    function finalAns(subtract){  //finalAns function is the callback function because it's passed as an argument to subOfTwo function and is called later inside subOfTwo with the result of the subtraction.
        console.log(subtract);
    }
    
    subOfTwo(finalAns);


    function divOfTwo(division){  //It takes another function (division) as an argument.
        let divide = 10 / 2;   //Inside divOfTwo, it computes a value (divide = 10 / 2), then calls the function division (which is passed as an argument) and passes divide as an argument to that function.
        division(divide) 
        }
        
        function finalAns(divide){
            console.log(divide);
        }
        
        divOfTwo(finalAns);