//String 
// let fullName ="Shayan Ali";


//Number
// let price = 999.99;

//Boolean
// let isFollow = true;

//null
// let a = null

//undefined
// let b;

//Object   (Home Task) 
// let student = {
//     fullName: "Shayan Ali",
//     age:18,
//     class: "12th",
//     isPass:true,
//     addres: {
//         pAddress:"hunza",
//         tAddress:"jutial"
//     },

//     hobbies: {
//         hobby1:"Drawing",
//         hobby2:"Travelling"
//     }
// }



// Object Adding, modification,

let myInfo= {
    first_name: "Muntazir",
    last_name: "Abbas",
    pAddres:"sultanabad",
    tAddress:"gilgit",
    full_name: function(){
        return this.first_name +  " " + this.last_name
    }


}
console.log(myInfo.first_name);

myInfo.skill = "Ui Ux Designer";
myInfo.hobbies ={
    hobby1 : "reading",
    hobby2 :"travelling"
}
delete myInfo.tAddress

console.log(myInfo);
console.log(myInfo.full_name());