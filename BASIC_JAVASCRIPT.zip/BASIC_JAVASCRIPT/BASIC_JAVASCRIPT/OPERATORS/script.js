//Arithmetic Operators
// let a = 4;
// let b = 3;

// console.log(a + b);
// console.log(a - b);
// console.log(a * b);
// console.log(a / b);
// console.log(a ** b);
// console.log(a % b);
// console.log(++a);
// console.log(--a);


//Assigement Operators

// let a = 4;
// let b = 3;

// console.log(a += b);
// console.log(a -= b);
// console.log(a *= b);
// console.log(a %= b);
// console.log("a *= b =",a *= b);
// console.log("a **= b =",a **= b);

//Comparison Operators

// let a = 5;
// let b = 2;

// console.log(a == b)
// console.log(a !== b)
// console.log(a === b)
// console.log(a !== b)

//Logical Operators

// let a = 5;
// let b = 2;

// let cond1 = a > b;
// let cond2 = a === b;

// console.log(cond1 && cond2);
// console.log(cond1 || cond2);
// console.log(!(cond2));