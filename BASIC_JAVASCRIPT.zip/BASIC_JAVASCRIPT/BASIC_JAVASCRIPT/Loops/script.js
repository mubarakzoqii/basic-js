// for loop

// for(let m = 1; m<=5; m++ ) {
//     console.log("Hello World!");
// }

// for(count = 2; count<=7; count++){
//     console.log("USDP");
// }

// Calulate of sum of 1 to 4

// let sum = 0;
// for(let i = 2; i <= 6; i++){
//     sum = sum + i;
// }
// console.log("sum =",sum);

// let num = 0;
// for(let m = 1; m <= 5; m++){
//     num = num +m;
// }
// console.log(num);

// while loop

let a = 1;
while(a<=5){
    console.log("Hello world");
    a++;
}

// do while loop

// let a = 1
// do{
//     console.log("Hello World!");
//     a++;
// } while(a <= 4);
