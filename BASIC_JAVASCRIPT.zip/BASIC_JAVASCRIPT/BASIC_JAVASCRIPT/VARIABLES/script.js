 let name ="Hello World";
 name ="Abbas"
 console.log(name);

 var space="Sultanabad";
 var space="Gilgit";
 console.log(space);

const age ="100";
price=20;
console.log(age);

const student = {
    fullName: "Ali",
    age: 18,
    isPass:true,
};
console.log(student);