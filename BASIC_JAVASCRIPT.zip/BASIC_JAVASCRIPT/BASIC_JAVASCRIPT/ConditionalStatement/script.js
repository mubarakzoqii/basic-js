// Conditional Statement

// if
// let age = 24;

// if(age > 18) {
//     console.log("You can vote");
// }

// let mode ="dark";
// let color;
// if(mode === "dark") {
//     color = "black";
// }

// if(mode ==="light"){
//     color = "white"
// }

// console.log(color);


// if - else

// let age = 24;

// if(age >= 18) {
//     console.log("you can vote");
// } else {
//     console.log("you can't vote");
// }

// let furit = "kiwi"
//  if(furit === "apple"){
//     console.log("apple");
//  } else{
//     console.log("orange");
//  }

//  let num = 18;

//  if(num%2 === 0) {
//     console.log("Even number");
//  }else{
//     console.log("Odd number");
//  }

//  else-if

// let  classes = "8th"

// if(classes > "8th") {
//     console.log("middle");
// } else if(classes < "12th") {
//     console.log("secondry");
// } else {
//     console.log("primary");
// }

// let age = 25;

// if(age < 18){
//     console.log("junoir");
// } else if(age > 50){
//     console.log("senior");
// }else{
//     console.log("adult");
// }

let marks = 90;
let grade;

switch (true) {
         case marks <= 32: 
         console.log( "fail");
        break;
        case marks >= 33 && marks <= 49: 
        console.log( "pass");
        break; 
        case marks >= 50 && marks <=59 : 
        console.log("D");
        break; 
        case marks >= 60 && marks <=69: 
        console.log("C");
        break;
        case marks >= 70 && marks <=79: 
        console.log("B");
        break;
        case marks >= 80 && marks <=89: 
        console.log("A");
        break;
        case marks >= 90 && marks <=100: 
        console.log("A+");
        break;

    default: 
        break;
}

// console.log(grade);