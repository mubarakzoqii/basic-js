let numbers = [1,2,3,4,5,6];
// let emptyArray = [];
// let multipleArray = ["saima", 39, true, {name: "ali", age: 7}]

console.log(numbers);
console.log(numbers[2]);
// console.log(typeof array);

// isArray()
// console.log(Array.isArray(numbers));


console.log(numbers.length);

//  concat()

let stdName  = ["umar", "umair", "ilyas"];
let stdName1 = ["shakeela", "mehnaz", "daniyal"];

webDevelopmentstds = stdName.concat(stdName1);
console.log(webDevelopmentstds);
// push()
webDevelopmentstds.push("shagufta", "Mubarak")
console.log(webDevelopmentstds);

// pop()
webDevelopmentstds.pop()
console.log(webDevelopmentstds);

//  shift()
webDevelopmentstds.shift()
console.log(webDevelopmentstds);
